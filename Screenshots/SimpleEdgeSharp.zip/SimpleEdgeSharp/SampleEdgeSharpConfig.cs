﻿using EdgeSharp.Core.Defaults;
using EdgeSharp.Core.Infrastructure;
using System;

namespace SimpleEdgeSharp
{
    internal class SampleEdgeSharpConfig : Configuration
    {
        public SampleEdgeSharpConfig() : base()
        {
            // var localResource = new UrlScheme("http", "app", null, UrlSchemeType.ResourceRequest);
            var hostToFolderscheme = new UrlScheme("http", "app", "app", UrlSchemeType.HostToFolder);

            //  UrlSchemes.Add(localResource);
            UrlSchemes.Add(hostToFolderscheme);

            var appDirectory = AppDomain.CurrentDomain.BaseDirectory;
            //var initialUrl = Path.Combine(appDirectory, "htf", "index.html");
            //var initialUrl = Path.Combine(appDirectory, "app", "index.html");
            // var initialUrl = "https://www.bing.com/";
            var initialUrl = "http://app/index.html";
            // var initialUrl = "http://htf/index.html";
            StartUrl = initialUrl;

            // Make borderless
            // WindowOptions.Borderless = true;
        }
    }
}
