﻿using EdgeSharp;
using System;

namespace SimpleEdgeSharp
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            AppBuilder
            .Create()
            .UseConfig<SampleEdgeSharpConfig>()
            .UseApp<SampleEdgeSharpApp>()
            .Build()
            .Run(args);
        }
    }
}
