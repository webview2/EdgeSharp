﻿using EdgeSharp;
using Microsoft.Extensions.DependencyInjection;

namespace SimpleEdgeSharp
{
    internal class SampleEdgeSharpApp : EdgeSharpApp
    {
        public override void ConfigureServices(IServiceCollection services)
        {
            base.ConfigureServices(services);
            // other service configuration can be placed here
        }
    }
}
